#!/bin/bash

sync
