#!/bin/bash

ldid -S/freya/default.ent -M -K/freya/signcert.p12 /Applications/Cydia.app/Cydia
rm -rf /Applications/Cydia.app/.ldid*
rm -rf /Applications/Cydia.app/ldid*
ldid -S/freya/default.ent -M -K/freya/signcert.p12 /usr/libexec/cydia/*
rm -rf /usr/libexec/cydia/.ldid*
rm -rf /usr/libexec/cydia/ldid*
#done   
uicache
sync
