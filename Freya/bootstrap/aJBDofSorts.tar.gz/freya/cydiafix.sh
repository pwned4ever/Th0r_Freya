#!/bin/bash
apt-get -y --allow-unauthenticated --allow-remove-essential purge cydia
echo deb https://shogunpwnd.github.io/cydia/. / >> /etc/apt/sources.list.d/freya.list
apt-get update
apt-get -y --allow-unauthenticated install cydia
rm -rf /etc/apt/sources.list.d/freya.list
rm -rf /etc/apt/freya
rm -rf /etc/apt/trusted.gpg.d
apt-get -y --allow-unauthenticated install libapt
apt-get update
apt-get -y --allow-unauthenticated install cydia

uicache
sync
