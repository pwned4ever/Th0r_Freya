#!/bin/bash

plutil -key SBShowNonDefaultSystemApps -value TRUE /var/mobile/Library/Preferences/com.apple.springboard.plist

#done   
