#!/bin/bash
apt-get -y --allow-unauthenticated --allow-remove-essential purge cydia
echo deb https://apt.bingner.com/. / >> /etc/apt/sources.list.d/freya.list
apt-get update
apt-get -y --allow-unauthenticated install cydia
apt-get -y --allow-unauthenticated install essential
rm -rvf /etc/apt/sources.list.d/freya.list
rm -rdvf /etc/apt/freya
uicache
