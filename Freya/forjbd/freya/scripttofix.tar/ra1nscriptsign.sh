#!/bin/bash

# /usr/bin \

#cp -R /Library/MobileSubstrate/DynamicLibraries/ /usr/lib/TweakInject/

#for dir in \
#    /Library/MobileSubstrate/DynamicLibraries \
#    /Library/PreferenceBundles/*/* \
#    /Library/PreferenceLoader/*/* \
#; do

ldid -S/freya/default.ent -M -K/freya/signcert.p12 /Library/MobileSubstrate/DynamicLibraries/*
rm -rf /Library/MobileSubstrate/DynamicLibraries/.ldid*
rm -rf /Library/MobileSubstrate/DynamicLibraries/ldid*
ldid -S/freya/default.ent -M -K/freya/signcert.p12 /usr/lib/TweakInject/*
rm -rf /usr/lib/TweakInject/.ldid*
rm -rf /usr/lib/TweakInject/ldid*
ldid -S/freya/default.ent -M -K/freya/signcert.p12 /Library/PreferenceLoader/*/*
rm -rf /Library/PreferenceLoader/*/.ldid*
rm -rf /Library/PreferenceLoader/*/ldid*
ldid -S/freya/default.ent -M -K/freya/signcert.p12 /usr/lib/SnowBoardBase.dylib
rm -rf /usr/lib/.ldid*
rm -rf /usr/lib/ldid*
ldid -S/freya/default.ent -M -K/freya/signcert.p12 /usr/local/bin/snowboardutil
rm -rf /usr/local/bin/.ldid*
ldid -S/freya/default.ent -M -K/freya/signcert.p12 /Library/PreferenceBundles/*/*
# "$@" "${dir}"
rm -rf /Library/PreferenceBundles/*/.ldid*
rm -rf /Library/PreferenceBundles/*/ldid*

#done

#    copyMe("/Library/MobileSubstrate/DynamicLibraries", "/usr/lib/TweakInject");//worked
   
sync
